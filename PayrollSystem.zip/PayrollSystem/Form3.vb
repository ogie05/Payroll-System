﻿Imports System.Data.OleDb
Imports System.Data

Public Class Form3
    Dim con As New OleDbConnection(My.Settings.systemConnectionString)


    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles login.Click
        If username.Text = Nothing Or password.Text = Nothing Then
            MsgBox("Please Input Credentials ", MsgBoxStyle.Exclamation)

        End If
        If con.State = ConnectionState.Closed Then
            con.Open()

        End If
        Dim logincmd As New OleDbCommand("select count(*) from system where username=? and password=?", con)
        logincmd.Parameters.AddWithValue("@2", OleDbType.VarChar).Value = username.Text
        logincmd.Parameters.AddWithValue("@3", OleDbType.VarChar).Value = password.Text
        Dim count = Convert.ToInt32(logincmd.ExecuteScalar())
        If count > 0 Then


            MsgBox("LOGIN SUCCESS" & vbNewLine & "LOGIN USER: " & username.Text, MsgBoxStyle.Information)
            Me.Hide()
            Main.Show()

        Else

            MsgBox("LOGIN FAILED", MsgBoxStyle.Critical)
        End If


    End Sub
End Class