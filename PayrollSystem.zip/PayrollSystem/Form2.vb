﻿Public Class Form2

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Main.Show()
        Me.Hide()

    End Sub
End Class